@extends("layouts.app")
@section("content")
    <div id="container">
        <section id="login">
            <div class="redirect_message">{{ $message }}</div>
        </section>
    </div>
@endsection
